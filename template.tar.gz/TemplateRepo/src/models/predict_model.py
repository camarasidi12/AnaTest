
from flask import Flask, request, redirect, url_for, flash, jsonify
import sys
sys.path.insert(0, 'C:\\Users\sidicamara\\Desktop\DataScienceProject\\TemplateRepo\src\\features')
from build_features import doTheCalculation
import json, pickle
import pandas as pd
import os
import numpy as np


ENV=os.getenv("PROJECT_DIR")
MODEL_SERIALIZE_PATH=ENV+os.getenv("MODEL_SERIALIZE_PATH")


app = Flask(__name__)


@app.route('/api/<string:algorithm>/', methods=['POST'])

def prediction(algorithm):
    """

    Function run at each API call

    """

    jsonfile = request.get_json()

    data = pd.read_json(json.dumps(jsonfile), orient='index', convert_dates=['dteday'])

    print(data)

    res = dict()

    if algorithm == "LR":
           ypred = modelLR.predict(doTheCalculation(data))
           print("Lenear regression apply")
    else:
           ypred = modelRF.predict(doTheCalculation(data))
           print("Random forest apply")

    for i in range(len(ypred)):
        res[i] = ypred[i]

    return jsonify(res)


if __name__ == '__main__':
    modelfileRF = MODEL_SERIALIZE_PATH+'modelRF.pickle'
    modelfileLR = MODEL_SERIALIZE_PATH + 'modelLR.pickle'

    modelRF = pickle.load(open(modelfileRF, 'rb'))
    modelLR = pickle.load(open(modelfileLR, 'rb'))
    print("loaded OK")

    app.run(debug=True,port=5000)